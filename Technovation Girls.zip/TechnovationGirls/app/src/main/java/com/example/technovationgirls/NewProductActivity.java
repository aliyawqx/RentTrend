package com.example.technovationgirls;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

public class NewProductActivity extends AppCompatActivity {

    EditText profileName, profilePrice, profileDescription, titleStoreName, profileContactInfo;
    String nameStr, priceStr, descriptionStr, storeNameStr, contactInfoStr;
    Button doneButton;
    ImageView imageView;
    FirebaseDatabase db;
    DatabaseReference stores, products;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_product);
        profileName = findViewById(R.id.profileName);
        profilePrice = findViewById(R.id.profilePrice);
        profileDescription = findViewById(R.id.profileDescription);
        titleStoreName = findViewById(R.id.titleStoreName);
        profileContactInfo = findViewById(R.id.profileContactInfo);
        doneButton = findViewById(R.id.doneButton);

        db = FirebaseDatabase.getInstance("https://technovation-girls-74b3e-default-rtdb.europe-west1.firebasedatabase.app/");
        stores = db.getReference().child("Stores");

        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nameStr = profileName.getText().toString();
                storeNameStr = titleStoreName.getText().toString();
                priceStr = profilePrice.getText().toString();
                descriptionStr = profileDescription.getText().toString();
                contactInfoStr = profileContactInfo.getText().toString();
                products = db.getReference().child("Products");
                Intent i = getIntent();
                String usernameStr = i.getStringExtra("username");
                Query checkStoreDatabase = stores.orderByChild("storeName").equalTo(storeNameStr);
                checkStoreDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        if (storeNameStr.isEmpty() || nameStr.isEmpty() || priceStr.isEmpty() || descriptionStr.isEmpty() || contactInfoStr.isEmpty()){
                            Toast.makeText(NewProductActivity.this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                        } else if (snapshot.exists() == false) {
                            Store store = new Store(storeNameStr, usernameStr);
                            DatabaseReference push = stores.push();
                            String key = push.getKey();
                            store.setKey(key);
                            push.setValue(store);

                            Product product = new Product(storeNameStr, nameStr, priceStr, descriptionStr, usernameStr, contactInfoStr);
                            DatabaseReference push1 = products.push();
                            String key1 = push1.getKey();
                            ArrayList<Product> productArrayList = new ArrayList<>();
                            productArrayList.add(product);
                            product.setKey(key1);
                            push1.setValue(product);
                            Intent i = new Intent(NewProductActivity.this, MainActivity.class);
                            Toast.makeText(NewProductActivity.this, "Successfully added", Toast.LENGTH_SHORT).show();
                            startActivity(i);
                        } else if (snapshot.exists() == false && snapshot.hasChild(usernameStr) == true) {
                            Toast.makeText(NewProductActivity.this, "You already have another store", Toast.LENGTH_SHORT).show();
                        } else {
                            Product product = new Product(storeNameStr, nameStr, priceStr, descriptionStr, usernameStr, contactInfoStr);
                            DatabaseReference push1 = products.push();
                            String key1 = push1.getKey();
                            ArrayList<Product> productArrayList = new ArrayList<>();
                            productArrayList.add(product);
                            product.setKey(key1);
                            push1.setValue(product);
                            Intent i = new Intent(NewProductActivity.this, MainActivity.class);
                            Toast.makeText(NewProductActivity.this, "Successfully added", Toast.LENGTH_SHORT).show();
                            startActivity(i);
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
            }
        });
    }
}