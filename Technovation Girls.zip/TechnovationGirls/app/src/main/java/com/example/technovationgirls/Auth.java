package com.example.technovationgirls;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Auth {
    private Context context;
    private HomeFragment homeFragment;
    private static User currentUser = null;
    private static String username = null;

    private static Store currentStore = null;
    private static Product currentProduct = null;
    private static String productName = null;
    private static String storeName = null;
    public Auth(Context context) {
        this.context = context;
    }

    public Auth(HomeFragment homeFragment) {
        this.homeFragment = homeFragment;
    }

    public static Product getCurrentProduct() {
        return currentProduct;
    }

    public static void setCurrentProduct(Product currentProduct) {
        Auth.currentProduct = currentProduct;
    }

    public static Store getCurrentStore() {
        return currentStore;
    }
    public static void setCurrentStore(Store currentStore) {
        Auth.currentStore = currentStore;
    }

    public static String getStoreName() {
        return storeName;
    }

    public static void setStoreName(String storeName) {
        Auth.storeName = storeName;
    }

    public static void getStoreByUsername(String storeName, StoreDataListener listener){
        FirebaseDatabase db = FirebaseDatabase.getInstance("https://technovation-girls-74b3e-default-rtdb.europe-west1.firebasedatabase.app/");
        DatabaseReference products = db.getReference().child("Stores");

        Query query = products.orderByChild("username").equalTo(storeName);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot document : snapshot.getChildren()) {
                    Store s = document.getValue(Store.class);

                    listener.OnStoreDataReady(s);
                    return;
                }
                listener.OnStoreDataReady(null);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                listener.OnStoreDataReady(null);
            }
        });
    }
    public String getProductNameFromSP() {
        if (Auth.productName == null) {
            SharedPreferences sp = context.getSharedPreferences("data",
                    context.MODE_PRIVATE);
            productName = sp.getString("product name", null);
        }
        return productName;
    }

    public String getStoreNameFromSP() {
        if (Auth.storeName == null) {
            SharedPreferences sp = context.getSharedPreferences("data",
                    context.MODE_PRIVATE);
            storeName = sp.getString("storeName", null);
        }
        return productName;
    }

    public void saveProductName(String productName) {
        Auth.productName = productName;
        SharedPreferences sp = context.getSharedPreferences("data",
                context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString("product name", productName);
        edit.apply();
    }


    public static void getProductByProductName(String ProductName, ProductDataListener listener){
        FirebaseDatabase db = FirebaseDatabase.getInstance("https://technovation-girls-74b3e-default-rtdb.europe-west1.firebasedatabase.app/");
        DatabaseReference products = db.getReference().child("Products");

        Query query = products.orderByChild("product name").equalTo(ProductName);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot document : snapshot.getChildren()) {
                    Product p = document.getValue(Product.class);

                    listener.OnProductDataReady(p);
                    return;
                }
                listener.OnProductDataReady(null);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                listener.OnProductDataReady(null);
            }
        });
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User currentUser) {
        Auth.currentUser = currentUser;
    }

    public String getUsernameFromSP() {
        if (Auth.username == null) {
            SharedPreferences sp = context.getSharedPreferences("data",
                    context.MODE_PRIVATE);
            username = sp.getString("username", null);
        }
        return username;
    }

    public void saveUsername(String username) {
        Auth.username = username;
        SharedPreferences sp = context.getSharedPreferences("data",
                context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString("username", username);
        edit.apply();
    }

    public static void saveUsername(String email, Context context) {
        Auth.username = email;
        SharedPreferences sp = context.getSharedPreferences("data",
                context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString("username", email);
        edit.apply();
    }

    public static void getUserByUsername(String username, UserDataListener listener) {
        FirebaseDatabase db = FirebaseDatabase.getInstance("https://technovation-girls-74b3e-default-rtdb.europe-west1.firebasedatabase.app/");
        DatabaseReference users = db.getReference().child("Users");

        Query query = users.orderByChild("username").equalTo(username);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot document : snapshot.getChildren()) {
                    User u = document.getValue(User.class);

                    listener.OnUserDataReady(u);
                    return;
                }
                listener.OnUserDataReady(null);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                listener.OnUserDataReady(null);
            }
        });
    }
}
