package com.example.technovationgirls;

public interface UserDataListener {
    void OnUserDataReady(User user);
}
