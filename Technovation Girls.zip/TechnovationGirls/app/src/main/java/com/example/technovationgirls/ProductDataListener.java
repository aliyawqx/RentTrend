package com.example.technovationgirls;

public interface ProductDataListener {
    void OnProductDataReady(Product product);
}
