package com.example.technovationgirls;

import static androidx.core.content.PackageManagerCompat.LOG_TAG;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class HomeFragment extends Fragment {

    ListView myList;
    ListAdapter adapter;
    FirebaseDatabase db;
    DatabaseReference products;
    ArrayList<Product> productArrayList = new ArrayList<>();
    Auth auth;
    private static final int INFOSTUDIOACTIVITY = 1;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        myList = view.findViewById(R.id.listView);
        adapter = new ListAdapter(getActivity(), productArrayList);
        myList.setAdapter(adapter);

        db = FirebaseDatabase.getInstance("https://technovation-girls-74b3e-default-rtdb.europe-west1.firebasedatabase.app/");
        products = db.getReference().child("Products");
        products.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot document : snapshot.getChildren()) {
                    Product p = document.getValue(Product.class);
                    productArrayList.add(p);
                }
                adapter.notifyDataSetChanged();
                afterCreate();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return view;
    }
    private void afterCreate() {

        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String id = (String) view.getTag();
                for (Product p : productArrayList) {
                    if (p.getKey().equals(id)) {
                        Intent intent = new Intent(getActivity(),
                                InfoActivity.class);
                        intent.putExtra("nameOfProduct", p.getNameOfProduct());
                        intent.putExtra("price", p.getPrice());
                        intent.putExtra("storeName", p.getStoreName());
                        intent.putExtra("description", p.getDescription());
                        intent.putExtra("contactInfo", p.getContactInfo());
                        startActivity(intent);
                        break;
                    }
                }
            }
        });
    }
}