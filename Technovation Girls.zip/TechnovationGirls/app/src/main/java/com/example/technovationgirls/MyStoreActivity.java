package com.example.technovationgirls;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MyStoreActivity extends AppCompatActivity {
    ListView myList;
    ListAdapter adapter;
    TextView storeName;
    FirebaseDatabase db;
    DatabaseReference products;
    ArrayList<Product> productArrayList = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_store);

        Intent i = getIntent();
        String username = i.getStringExtra("username");
        storeName = findViewById(R.id.titleStoreName);

        myList = findViewById(R.id.listView);
        adapter = new ListAdapter(this, productArrayList);
        myList.setAdapter(adapter);

        db = FirebaseDatabase.getInstance("https://technovation-girls-74b3e-default-rtdb.europe-west1.firebasedatabase.app/");
        products = db.getReference().child("Products");

        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MyStoreActivity.this)
                        .setTitle("Delete")
                        .setMessage("Are you sure you want to delete?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                products.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        for (DataSnapshot document : snapshot.getChildren()) {
                                            Product p = document.getValue(Product.class);
                                            products.child(p.getKey()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()){
                                                        adapter.notifyDataSetChanged();
                                                        Toast.makeText(MyStoreActivity.this, "Successfully deleted", Toast.LENGTH_SHORT).show();
                                                        MyProfileFragment myProfileFragment = new MyProfileFragment();
                                                        getSupportFragmentManager().beginTransaction()
                                                                .replace(R.id.content_frame2, myProfileFragment)
                                                                .addToBackStack(MyStoreActivity.class.getSimpleName())
                                                                .commit();
                                                    }
                                                    else{
                                                        Toast.makeText(MyStoreActivity.this, "Something went wrong. Please try again", Toast.LENGTH_SHORT).show();
                                                    }
                                                }
                                            });
                                        }
                                        adapter.notifyDataSetChanged();
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });
                            }
                        }).setNegativeButton("No", null);
                builder.show();
            }
        });

        products.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot document : snapshot.getChildren()) {
                    Product p = document.getValue(Product.class);
                    if (p.getUsername().equals(username)){
                        String storeNameStr = p.getStoreName();
                        storeName.setText(storeNameStr);
                        productArrayList.add(p);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}