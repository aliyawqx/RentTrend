package com.example.technovationgirls;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class InfoActivity extends AppCompatActivity {
    TextView storeName, nameOfProduct, price, description, contactInfo;
    Auth auth;
    Button buyBtn;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        storeName = findViewById(R.id.storeName);
        nameOfProduct =findViewById(R.id.nameOfProduct);
        price = findViewById(R.id.price);
        description = findViewById(R.id.description);
        contactInfo = findViewById(R.id.contactInfo);

        buyBtn = findViewById(R.id.buyButton);

        auth = new com.example.technovationgirls.Auth(this);

        Intent i = getIntent();
        String usernameStr = i.getStringExtra("username");
        Auth.getStoreByUsername(auth.getStoreNameFromSP(), new StoreDataListener() {
            @Override
            public void OnStoreDataReady(Store store) {
                if (store == null) {
                } else {
                    Auth.setCurrentStore(store);
                }
            }
        });
        Auth.getProductByProductName(auth.getProductNameFromSP(), new ProductDataListener() {
            @Override
            public void OnProductDataReady(Product product) {
                if (product == null) {
                } else {
                    Auth.setCurrentProduct(product);
                }
            }
        });

        String storeNameStr = i.getStringExtra("storeName");
        String nameOfProductStr = i.getStringExtra("nameOfProduct");
        String priceStr = i.getStringExtra("price");
        String descriptionStr = i.getStringExtra("description");
        String contactInfoStr = i.getStringExtra("contactInfo");

        storeName.setText(storeNameStr);
        nameOfProduct.setText(nameOfProductStr);
        price.setText(priceStr);
        description.setText(descriptionStr);

        buyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(InfoActivity.this).setTitle("Contact info: " + contactInfoStr).show();
            }
        });
    }
}