package com.example.technovationgirls;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class LoginActivity extends AppCompatActivity {
    EditText etUsername, etPasswd, etEmail;
    DatabaseReference users;
    FirebaseDatabase db;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        etUsername = findViewById(R.id.inputUsername);
        etPasswd = findViewById(R.id.inputPassword);
        etEmail = findViewById(R.id.inputEmail);
        Button btn = findViewById(R.id.btnLogin);

        db = FirebaseDatabase.getInstance("https://technovation-girls-74b3e-default-rtdb.europe-west1.firebasedatabase.app/");
        users = db.getReference().child("Users");

        TextView btnSignUp = findViewById(R.id.textViewSignUp);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameStr = etUsername.getText().toString();
                String passwdStr = etPasswd.getText().toString();
                String emailStr = etEmail.getText().toString();

                Auth.getUserByUsername(usernameStr, new UserDataListener() {
                    @Override
                    public void OnUserDataReady(User user) {
                        if (passwdStr.isEmpty() || usernameStr.isEmpty() || emailStr.isEmpty()) {
                            Toast.makeText(LoginActivity.this, "Please fill out all fields", Toast.LENGTH_LONG).show();
                        }
                        else if (user != null && user.getPasswd().equals(passwdStr) && user.getUsername().equals(usernameStr) && user.getEmail().equals(emailStr)) {

                            Auth auth = new com.example.technovationgirls.Auth(getApplicationContext());
                            Auth.setCurrentUser(user);
                            auth.saveUsername(user.getUsername());
                            Auth.saveUsername(user.getUsername(), getApplicationContext());

                            Intent intent = new Intent(getApplicationContext(),
                                    MainActivity.class);
                            intent.putExtra("username", usernameStr);
                            intent.putExtra("email", emailStr);
                            intent.putExtra("password", passwdStr);

                            Toast.makeText(LoginActivity.this, "You logged in successfully", Toast.LENGTH_LONG).show();
                            startActivity(intent);
                        } else if (user == null) {
                            Toast.makeText(LoginActivity.this, "This user does not exist. Please register first", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(LoginActivity.this, "Incorrect username or password", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, SignUpActivity.class));
            }
        });
    }
}