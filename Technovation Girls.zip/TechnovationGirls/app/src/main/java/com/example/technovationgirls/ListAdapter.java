package com.example.technovationgirls;

import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import java.util.ArrayList;

public class ListAdapter extends ArrayAdapter<Product> {

    Context context;
    ArrayList<Product> productArrayList;
    public ListAdapter(@NonNull Context context, ArrayList<Product> dataArrayList) {
        super(context, R.layout.list_item, dataArrayList);
        this.context = context;
        this.productArrayList = dataArrayList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View view, @NonNull ViewGroup parent) {
        Product productData = this.productArrayList.get(position);

        LayoutInflater inflater = LayoutInflater.from(this.context);
        view = inflater.inflate(R.layout.list_item, null, false);
        view.setClickable(true);

//        ImageView listImage = view.findViewById(R.id.listImage);
        TextView listName = view.findViewById(R.id.listName);
        TextView listPrice = view.findViewById(R.id.listPrice);
        TextView listStoreName = view.findViewById(R.id.listDescription);

//        listImage.setImageResource(productData.getImage());
        listName.setText(productData.getNameOfProduct());
        listPrice.setText(productData.getPrice());
        listStoreName.setText(productData.getDescription());

        view.setTag(productData.getKey());

        return view;
    }

}
