package com.example.technovationgirls;

import android.widget.ImageView;

import java.io.Serializable;

public class Product implements Serializable {
    private static int CURRENT_ID = 1;
    private String key;
    private String nameOfProduct;
    private String price;
    private String description;
    private String username;
    private String storeName;
    private String contactInfo;
    private String imageURL;

    public Product() {
        this.key = (CURRENT_ID++) + "";
    }

    public Product(String storeName, String nameOfProduct, String price, String description, String username, String contactInfo) {
        this.storeName = storeName;
        this.nameOfProduct = nameOfProduct;
        this.price = price;
        this.description = description;
        this.username = username;
        this.contactInfo = contactInfo;
    }

    public Product(String storeName, String nameOfProduct, String price, String description) {
        this.storeName = storeName;
        this.nameOfProduct = nameOfProduct;
        this.price = price;
        this.description = description;
    }

    public Product(String storeNameStr, String nameStr, String priceStr, String descriptionStr, String usernameStr, String contactInfoStr, String imageURL) {
        this.storeName = storeNameStr;
        this.nameOfProduct = nameStr;
        this.price = priceStr;
        this.description = descriptionStr;
        this.username = usernameStr;
        this.contactInfo = contactInfoStr;
        this.imageURL = imageURL;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNameOfProduct() {
        return nameOfProduct;
    }

    public void setNameOfProduct(String nameOfProduct) {
        this.nameOfProduct = nameOfProduct;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    public Product(String nameOfProduct, String price, String description) {
        this.nameOfProduct = nameOfProduct;
        this.price = price;
        this.description = description;
    }
    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public String getPrice() {
        return price;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }
}