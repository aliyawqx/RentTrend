package com.example.technovationgirls;

public interface StoreDataListener {
    void OnStoreDataReady(Store store);
}
