package com.example.technovationgirls;

import java.io.Serializable;

public class Store implements Serializable {
    private static int CURRENT_ID = 1;
    private String key;
    private String storeName, username;

    public Store() {
        this.key = (CURRENT_ID++) + "";
    }

    public Store(String storeName, String username) {
        this.username = username;
        this.storeName = storeName;
    }
    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStoreName() {
        return storeName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
